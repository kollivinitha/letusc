//program that displays the information about the student based on the given data.
# include <stdio.h>
int func(int x)
{
    return (1 << x);
} 
int main( )
{
    int i, num, roomnum ;
    unsigned short int data[ ] = { 273, 548, 786, 1096 } ; 
    for ( i = 0 ; i < 4 ; i++ )
    {
        num = data[ i ] ;
        if((num & func(0)) == func(0)) 
            printf("Year: First year\n") ;
        if((num & func(1)) == func(1)) 
            printf("Year: Second year\n") ;
        if((num & func(2)) == func(2)) 
            printf("Year: Third year\n") ;
        if((num & func(3)) == func(3)) 
            printf("Year: Fourth year\n") ;
        if((num & func(4)) == func(4)) 
            printf("Branch: Mechanical\n") ;
        if((num & func(5)) == func(5)) 
            printf("Branch: Chemical\n") ;
        if((num & func(6)) == func(6)) 
            printf("Branch: Electronics\n") ;
        if((num & func(7)) == func(7)) 
            printf("Branch: CS\n") ;
        roomnum = num >> 8 ;
        printf("Room number: %d\n", roomnum) ;
    }
    return 0 ;
}