//Program to convert integer to Roman number
#include<stdio.h>
#include<math.h>
int romanise(int y,int val,char ch)
{
    int x=y/val;
    for(int i=0;i<x;i++)
    {
        printf("%c",ch);
    }
    return y%val;
}
int main()
{
    int yr;
    printf("Enter an Year: ");
    scanf("%d",&yr);
    yr=romanise(yr,1000,'m');
    yr=romanise(yr,500,'d');
    yr=romanise(yr,100,'c');
    yr=romanise(yr,50,'l');
    yr=romanise(yr,10,'x');
    yr=romanise(yr,5,'v');
    yr=romanise(yr,1,'i');
}