//program to find the absolute value of a number entered through the keyboard
#include<stdio.h>
#include<math.h>
int main()
{
    int x;
    printf("Enter a number: ");
    scanf("%d",&x);

    //Can Also Builtin abs function
    if(x<0)
    {
        x*=-1;
    }
    printf("%d",x);

}