/*program using pointers to find the smallest number in an 
array of 25 integers.*/
#include<stdio.h>
int n;
int find_smallest(int* arr)
{
    int small=arr[0];
    for(int i=1;i<n;i++)
    {
        if(*(arr+i) <small)
        {
            small=*(arr+i);
        }
    }
    return small;
}
int main()
{
    printf("Enter the number of Elements: ");
    scanf("%d",&n);
    int arr[n];
    for(int i=0;i<n;i++)
    {
        printf("enter the element: ");
        scanf("%d",arr+i);
    }
    int x=find_smallest(&arr[0]);
    printf("Smallest Element is %d",x);
}