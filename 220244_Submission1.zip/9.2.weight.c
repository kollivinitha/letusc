//Program to convert weight to grams,tons,pounds
#include<stdio.h>
void conversion(int w,double *kg,double *tons,double *pounds)
{
    *kg=((float)w)/1000;
    *tons=(*kg)/1000;
    *pounds=*tons/2000;
}
int main()
{
    int w;
    printf("Enter the weight of a commodity: ");
    scanf("%d",&w);
    double kg,tons,pounds;
    //Call by reference
    //Pass the arguments address
    conversion(w,&kg,&tons,&pounds);
    printf("Weight in kilogram is %f\nWeight in tons is %f\nWeight in pounds is %f",kg,tons,pounds);
}