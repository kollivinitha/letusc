//Macro to find absolute value of a number
#include<stdio.h>
#include<math.h>
#define ABS(a,b) (a-b)
int main()
{
    int x,y;
    printf("Enter two Numbers: ");
    scanf("%d %d",&x,&y);
    double m=ABS(x,y);
    printf("Mean is %lf",m);
}