// program to print out all Armstrong numbers between 1 and 500.
#include<stdio.h>
#include<math.h>
int main()
{
    int i=1;
    while(i<500)
    {
        int res=0;
        int n=i;
        int temp=n;
        while(n!=0)
        {
            res+=pow(n%10,3);
            n=n/10;
        }
        if(res==temp)
        {
            printf("%d is Amstrong Number\n",temp);
        }
        i+=1;
    }
    return 0;
}