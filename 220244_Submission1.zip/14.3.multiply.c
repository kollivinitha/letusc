//program to multiply any two 3 x 3 matrices.
#include<stdio.h>
int main()
{
    int A[3][3];
    int B[3][3];
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            printf("Enter the Element of A: ");
            scanf("%d",&A[i][j]);
        }
    }
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            printf("Enter the Element of B: ");
            scanf("%d",&B[i][j]);
        }
    }
    int sum;
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            sum = 0 ;
            for (int k=0;k<=2;k++)
                sum = sum + A[i][k] * B[k][j];
            printf("%d ",sum);
        }
        printf("\n");
    }
    return 0;
}