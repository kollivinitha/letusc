//Program to find out if a point lies on x-axis, y-axis or origin.
#include<stdio.h>
int main()
{
    int x,y;
    printf("Enter the point: ");
    scanf("%d %d",&x,&y);
    if(x==0 && y==0)
    {
        printf("Point lies on origin");
    }
    else if(x==0)
    {
        printf("Point lies on Y-axis");   
    }
    else if(y==0){
        printf("Point lies on X-axis");
    }
    else{
        printf("Point doesnot lies on any of them");
    }
}