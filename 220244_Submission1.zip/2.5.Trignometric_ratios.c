// program to print all its Trigonometric ratios.
#include<stdio.h>
#include<math.h>
int main()
{
    double x;
    printf("Enter the angle: ");
    scanf("%lf",&x);
    
    //Using Built in Functions
    printf("Sinx=%d\n",sin(x));
    printf("Cosx:%d\n",cos(x));
    printf("Tanx:%d\n",tan(x));
    printf("Cosecx:%d\n", 1/(cos(x)));

}