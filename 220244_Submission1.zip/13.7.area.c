//The area of a triangle using sine Law
#include<stdio.h>
#include<math.h>
int main()
{
    int n;
    float angle,a,b;
    printf("Enter the number of Elements: ");
    scanf("%d",&n);
    float arr[n];
    
    for(int i=0;i<n;i++)
    {
        printf("Enter the sides: ");
        scanf("%f %f",&a,&b);
        printf("Enter the Angle: ");
        scanf("%f",&angle);

        //Formula
        float area=0.5*a*b*(sin(angle));
        printf("Area is %f\n",area);
        arr[i]=area;
    }
    float l=arr[0];
    for(int i=0;i<n;i++)
    {
        if(arr[i]>l)
            l=arr[i];
    }
    printf("Largest Area is: %f",l);
}