/* program to find out whether the college won the Champion of the Champions trophy or not, along with the names of the games won by the college.*/
# include <stdio.h>
int main( )
{
    int game ;
    int c, count = 0 ;
    printf ("\nEnter any number: ") ; 
    scanf ("%d", &game);
    for (c = 1 ; c <= 256 ; c *= 2)
    {
        if ((game & c ) == c) /* bits 0 to 7 */ 
            count++ ;
    }
    printf ("Matches won by the college are: %d\n", count); 
    if (count >= 5)
    {
        printf ("College won Champion of Champions trophy\n"); 
        printf ("The games won by the college are:\n");
        if ((game & 1) == 1) /* bit 0 */ 
            printf ("Cricket\n") ;
        if ((game & 2) == 2) /* bit 1 */ 
            printf ("Basketball\n") ;
        if ((game & 4) == 4) /* bit 2 */ 
            printf ("Football\n") ;
        if ((game & 8) == 8) /* bit 3 */ 
            printf ("Hockey\n") ;
        if ((game & 16) == 16) /* bit 4 */ 
        printf ("Lawn tennis\n") ;
        if ((game & 32) == 32) /* bit 5 */ 
            printf ("Table tennis\n") ;
        if ((game & 64) == 64) /* bit 6 */ 
            printf ("Carom\n") ;
        if ((game & 128) == 128) /* bit 7 */
            printf ("Chess\n") ;
    }
    return 0 ;
}

