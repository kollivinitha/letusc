/* To store joining dates using bit fields */
#include<stdio.h>
int main( )
{
    struct date
    { 
        unsigned day : 5;
        unsigned month : 4;
        unsigned year : 12;
    } ;
    struct date date[10], temp;
    int i, j, d, m, y;
    printf("Enter joining dates (dd-mm-yyyy) of 10 employees\n");
    for (i=0;i<10;i++)
    {
        scanf("%d %d %d",&d,&m,&y);
        if(d<1||d>31||m<1||m>12 ) 
        {
            printf("Invalid date, enter new date\n");
            i--;
            continue;
        }
        date[i].day = d;
        date[i].month = m ;
        date[i].year = y ;
    }
    for(i=0;i<9;i++)
    {
        for(j=i+1;j<10;j++)
        {
            if(date[j].year<date[i].year)
            {
                temp = date[i];
                date[i] = date[j];
                date[j] = temp;
            }
        }
    }
    for(i=0;i<10;i++)
        printf("%d %d %d\n", date[i].day, date[i].month, date[i].year);
    return 0 ;
}