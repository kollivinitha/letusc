//converting temperature from Fahrenheit to Celsius
#include<stdio.h>
int main()
{
    printf("Enter the temperature: ");
    int temp;
    scanf("%d",&temp);
    //Formula 
    int celsius=(temp-32)/1.8;
    printf("%d",celsius);
    return 0;
}