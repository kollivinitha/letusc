//Any year is entered through the keyboard. Write a function to determine whether the year is a leap year or not.
#include<stdio.h>
#include<math.h>
void is_leap(int year)
{
    if(year%100 != 0 || year%400 == 0 && year %4==0)
    {
        printf("Leap Year");
    }
    else{
        printf("Not a Leap Year");
    }
}
int main()
{
    int year;
    printf("Enter the Year: ");
    scanf("%d",&year);
    is_leap(year);
}