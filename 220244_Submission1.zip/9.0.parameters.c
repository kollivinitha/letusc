#include<stdbool.h>
#include<stdio.h>
void evaluate(int r,int *area,int *perimeter)
{
    *area=(3.14)*r*r;
    *perimeter=2*3.14*r;
}
int main()
{
    int r;
    printf("Enter the radius of the circle: ");
    scanf("%d",&r);
    int area,perimeter;
    evaluate(r,&area,&perimeter);
    printf("%d ",area);
    printf("%d",perimeter);
}