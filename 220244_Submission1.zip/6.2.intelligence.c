//Program to calculate intelligence of a person can be calculated using the following formula:i = 2 + ( y + 0.5 x )
#include<stdio.h>
#include<math.h>
int main()
{
    for(int y=1;y<=6;y++)
    {
        for(float x=5.5;x<=12.5;x+=0.5)
        {
            printf("%d %d %d\n",(2+(y+(0.5*x))),y,x);
        }
    }
}