#include<stdio.h>
int main()
{
    int r=34;
    int *j=&r;
    int **k=&j;
    int ***l=&k;
    printf("The value of r is %d %d %d %d\n",r,*j,**k,***l);
    printf("Address of r is %p %p\n",&r,j);
    printf("Address of j is %p %p\n",&j,k);
}