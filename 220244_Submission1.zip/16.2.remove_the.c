//Program to Remove "the" from the given String
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
    char st[100];
    char res[100]="";
    printf("Enter the String: ");
    gets(st);
    //Spliting the string into words
    char* token=strtok(st," ");
    while (token!=NULL)
    {
        if(strcmp(strlwr(token),"the")!=0)
        { 
            strcat(res,token);
            strcat(res," ");
        }
        token=strtok(NULL," ");
    }
    printf("\nModified String is %s",res);
    return 0;
}