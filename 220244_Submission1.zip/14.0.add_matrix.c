//program to add two 6 x 6 matrices. 
#include<stdio.h>
int main()
{
    int n=6;
    int A[6][6];
    int B[6][6];
    for(int i=0;i<6;i++)
    {
        for(int j=0;j<6;j++)
        {
            printf("Enter the Element: ");
            scanf("%d",&A[i][j]);

        }
    }
    for(int i=0;i<6;i++)
    {
        for(int j=0;j<6;j++)
        {
            printf("Enter the Element of B: ");
            scanf("%d",&B[i][j]);
        }
    }
    for(int i=0;i<6;i++)
    {
        for(int j=0;j<6;j++)
        {
            printf("%d ",A[i][j]+B[i][j]);
        }
        printf("\n");
        
    }
}