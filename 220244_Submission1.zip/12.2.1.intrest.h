/* Storing the macro definitions of Simple Interest and Amount in 
the “interest.h” header file */
#define SI( p, n, r ) ( p * n * r / 100 )
#define AMT( p, SI ) ( p + SI 