//Macro to find arithmetic mean of two numbers
#include<stdio.h>
#define MEAN(a,b) (a+b)/2
int main()
{
    int x,y;
    printf("Enter two Numbers: ");
    scanf("%d %d",&x,&y);
    int m=MEAN(x,y);
    printf("Mean is %d",m);
}