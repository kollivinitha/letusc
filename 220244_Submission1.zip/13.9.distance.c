//program to find the distance of last point
#include<stdio.h>
#include<math.h>
int main()
{
    int n=10;
    float x[n],y[n];
    for(int i=0;i<n;i++)
    {
        printf("Enter the coordinates: ");
        scanf("%f %f",&x[i],&y[i]);
    }
    float s=0;
    for(int i=0;i<n-1;i++)
    {
        s+=sqrt(pow(x[i+1]-x[i],2)+pow(y[i+1]-y[i],2));

    }
    printf("Distance is: %f",s);
}