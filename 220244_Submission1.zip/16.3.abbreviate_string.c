/*Program that stores a set of names of individuals and 
abbreviates the first, middle and other names except the last name 
by their first letter.
*/
#include<stdio.h>
#include<string.h>
int main()
{
    char name[50],s[30],res[20];
    int c=0,i=0;
    printf("Enter your Name: ");
    gets(name);
    char *token;
    token=strtok(name," ");
    char last[20];
    while(token != NULL)
    {
        c+=1;
        res[i++]=*token;
        res[i++]='.';
        strcpy(last,token);
        token=strtok(NULL," ");

    }
    res[i-2]='\0';
    strcat(res,last);
    printf("%s",res);
    return 0;
}