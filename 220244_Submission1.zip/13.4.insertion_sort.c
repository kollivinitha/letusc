//   Insertion Sort algorithm
#include<stdio.h>
int main()
{
    int n;
    printf("Enter the number of Elements: ");
    scanf("%d",&n);
    int arr[n];
    
    for(int i=0;i<n;i++)
    {
        printf("Enter the Element: ");
        scanf("%d",&arr[i]);
    }
    for(int i=0;i<n-1;i++)
    {
        int min=arr[i+1];
        int j,x;
        for(j=i+2;j<n;j++)
        {
            if(arr[j]<min)
            {
                min=arr[j];
                x=j;
            }
        }
        int temp=arr[i];
        arr[i]=arr[x];
        arr[x]=temp;
    }
    for(int i=0;i<n;i++)
    {
        printf("%d ",arr[i]);
    }
}