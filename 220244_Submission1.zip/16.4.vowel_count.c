//Program to count the number of occurrences of any two vowels in succession in a line of text
#include<stdio.h>
#include<string.h>
#include<stdbool.h>
#include<ctype.h>
bool is_vowel(char ch)
{
    ch=tolower(ch);
    if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
    {
        return true;
    }
    return false;
}
int main()
{
    char *s;
    printf("Enter a String: ");
    gets(s);
    int n=strlen(s);
    int c=0;
    //s = (char*)malloc((n + 1) * sizeof(char));
    for(int i=0;i<n-1;i++)
    {
        if(is_vowel(s[i]) && is_vowel(s[i+1]))
        {
            c+=1;
        }
    }
    printf("No.of Occurences is %d",c);
    return 0;
}