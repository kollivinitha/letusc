/* Calculate distance between two points and use the function
 to calculate area of triangle given its three vertices */

#include<stdio.h>
#include<math.h>
void area(int a,int b)
{
    /*Area of Triangle is 1/2(a*b) ;
    where a,b are length of the sides*/
    float ar=0.5*a*b;
    printf("%f ",ar);
}

void find_distance(int x1,int y1,int x2,int y2,int x3,int y3)
{
    int l1,l2,l3;
    //Formula to find length of a side is (x2-x1)^2 + (y2-y1)^2
    l1=pow(abs(x2-x1),2)+pow(abs(y2-y1),2);
    l2=pow(abs(x3-x2),2)+pow(abs(y2-y3),2);
    l3=pow(abs(x3-x1),2)+pow(abs(y3-y1),2);
    area(l1,l2);
}

int main()
{
    int x1,y1,x2,y2,x3,y3;
    printf("Enter the first Point A: ");
    scanf("%d %d",&x1,&y1);
    printf("Enter the Second Point B: ");
    scanf("%d %d",&x2,&y2);
    printf("Enter the Third Point C: ");
    scanf("%d %d",&x3,&y3);
    find_distance(x1,y1,x2,y2,x3,y3);
}