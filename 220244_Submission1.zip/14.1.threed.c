/*Program to initialize a three-dimensional array threed[3][2][3]?
and to demonstrate how to refer the first and last element in this array?
*/
#include<stdio.h>
int main()
{
    int x[3][2][3]={
                    {{4,6,7},{4,5,9}},
                    {{1,2,3},{4,6,8}},
                    {{5,6,8},{5,9,0}}
                    };
    printf("First Element is %d\n",x[0][0][0]);
    printf("Last Element is %d",x[2][1][2]);

}