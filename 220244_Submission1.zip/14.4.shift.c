//Program to shift an array circularly by two positions
int main()
{
    int p[5]={15,30,28,19,61};
    for(int i=0;i<;i++)
    {

    }
    return 0;
}