//Program to move the disks from peg A to peg C, using peg B as an auxiliary peg.
#include<stdio.h>
#include<string.h>
//Recursive Function
void TOH(int n,char A,char B,char C)
{
    //Recursive Part
    if(n>0)
    {
        TOH(n-1,A,C,B);
        printf("%c-%c\n",A,C);
        TOH(n-1,B,A,C);
    }
    //Base Part
    return;
}

int main()
{
    int pegs=3;
    //Calling recursive Function
    TOH(pegs,'A','B','C');
    return 0;
}