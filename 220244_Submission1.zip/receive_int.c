//If an integer is to be entered through the keyboard, which function would you use?
#include<stdio.h>
int main()
{
    int n;
    printf("Enter a number: ");
    //there is no console i/o function to get integer.Only scanf() can be used. 
    scanf("%d",&n);
    printf("Entered number is %d",n);
    return 0;
}