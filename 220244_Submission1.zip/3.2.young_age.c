//Program to find younger of Ram,Shyam and Ajay
#include<stdio.h>
int main()
{
    int x,y,z;
    printf("Enter the age of three : ");
    scanf("%d %d %d",&x,&y,&z);
    if(x<y && x<z)
    {
        printf("Ram is Younger");
    }
    else if(y<x && y<z)
    {
        printf("Shyam is Younger");
    }
    else{
        printf("Ajay is Younger");
    }
}