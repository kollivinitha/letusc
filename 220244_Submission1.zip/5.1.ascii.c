//program to print all the ASCII values and their equivalent characters using a while loop. The ASCII values vary from 0 to 255.
#include<stdio.h>
int main()
{
    
    int i=0;
    while(i<255)
    {
        char c=(char)i;
        printf("Character at %d is %c\n",i,c);
        i+=1;
    }
}