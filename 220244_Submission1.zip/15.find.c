#include<stdio.h>
int main()
{
    int n;
    printf("Enter the length of the string: ");
    scanf("%d",&n);
    char st[21];
    printf("Enter the String: ");
    scanf("%[ ^\n ]s",&st);
    gets(st);
    printf("%s",st);

}