//Program to find prime factors of the given number
#include<stdio.h>
#include<math.h>
void prime_factors(int n)
{
    int temp=n;
    for(int i=2;i<temp;i++)
    {
        while(n%i==0)
        {
            printf("%d ",i);
            n=n/i;
        }
    }
}
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d",&n);
    prime_factors(n);
}