//program to obtain the reversed number and to determine whether the original and reversed numbers are equal or not.
#include<stdio.h>
int main()
{
    int n,res=0;
    
    printf("Enter the Number: ");
    scanf("%d",&n);
    int temp=n;
    while(n!=0)
    {
        res=res*10+(n%10);
        n=n/10;
    }
    if(res==temp)
    {
        printf("EQUAL");
    }
    else{
        printf("NOT EQUAL");
    }
}