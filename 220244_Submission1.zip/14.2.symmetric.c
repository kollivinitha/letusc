//Program to find if a matrix is symmetric
#include<stdio.h>
int main()
{
    int n;
    printf("Enter the number of rows in a matrix: ");
    scanf("%d",&n);
    int A[n][n];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("Enter the Element: ");
            scanf("%d",&A[i][j]);
        }
    }
    //If (A)Transpose is equal to A,then matrix is Symmetric.
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(A[i][j] != A[j][i])
            {
                printf("Not a Symmetric Matrix");
                return 0;
            }
        }
        printf("Symmetric Matrix");
    }

    return 0;
}