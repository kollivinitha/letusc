// program to interchange the contents of C and D

#include<stdio.h>
int main()
{
    int c,d;
    printf("Enter the values of C and D: ");
    scanf("%d %d",&c,&d);

    
    c=c+d;
    d=c-d;
    c=c-d;
    printf("Interchanged values %d %d",c,d);
}