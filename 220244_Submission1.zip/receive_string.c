//To receive the string "We have got the guts, you get the glory!!"
#include<stdio.h>
#include<string.h>
int main()
{
    char str[100];
    printf("Enter a String: ");
    //Use console i/o function gets() to receive the string. 
    gets(str);
    printf("%s",str);
    return 0;
}