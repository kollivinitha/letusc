//program that receives an integer (less than or equal to nine digits in length) and prints out the number in words. 
#include<stdio.h>
#include<string.h>
char* s1[]={"one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","ninteen"};
char* s2[]={"twenty","thirty","forty","fifty","sixty","seventy","eighty","ninty"};
void num_to_word(int n,char* s)
{
    if(n)
    {
        if(n>19)
        {
            printf("%s %s ",s2[(n/10)-2],s1[(n%10)-1]);
        }
        else{
            printf("%s ",s1[n-1]);
        }
        printf("%s ",s);
    }
}
int main()
{
    long num;
    printf("Enter a number: ");
    scanf("%ld",&num);
    num_to_word(num/10000000,"crore");
    num_to_word((num/100000)%100,"lakh");
    num_to_word((num/1000)%100,"thousand");
    num_to_word((num/100)%10,"hundred");
    num_to_word(num%100,"");
}