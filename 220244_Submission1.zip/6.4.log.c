//Program to calculate natural Logarithm
#include<stdio.h>
#include<math.h>
int main()
{
    int x;
    printf("Enter the value of x: ");
    scanf("%d",&x);
    float s=(1.0*x-1)/x;
    for(int i=2;i<7;i++)
    {
        s+=0.5*pow(((1.0*x-1)/x),i);
    }
    printf("Sum of first Seven terms is %f",s);
}