#include<stdio.h>
#include<string.h>
int main()
{
    char s[20];
    char str1[10],str2[10],str3[10],str4[10];
    printf("Enter the String: ");
    scanf("%s %s %s %s",str1,str2,str3,str4);
    printf("%s %s %s %s",str1,str2,str3);
}