//Program to delete all vowels from a sentence.
#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main()
{
    char st[81];
    
    printf("Enter the Sentence: ");
    gets(st);
    int n=strlen(st);
    char res[81];
    int j=0;
    for(int i=0;i<n;i++)
    {
        char ch=tolower(st[i]);
        if(ch=='i'||ch=='a'||ch=='e'||ch=='o'||ch=='u')
        {
            continue;
        }
        else
        {
            res[j++]=st[i];
        }
    }
    res[j]='\0';
    printf("Modified String is %s",res);
    return 0;
}