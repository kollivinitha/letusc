//Program to implement dequeue using Array
# include <stdio.h>
//Function to add data at front
void add_front ( int ) ;
void add_rear ( int ) ;
int retrieve_front( ) ;
int retrieve_rear( ) ;
void display( ) ;
int *front, *rear ;
int a[ 26 ] ;
int main( )
{
    int item ;
    front = NULL ;
    rear = NULL ;
    printf ( "\nAdding elements at front of a deque: " ) ;
    add_front (5) ;
    add_front (4 ) ;
    add_front (7) ;
    display( ) ;
    printf ( "\n\nAdding an element at rear of a deque: " ) ;
    add_rear (6) ;
    display( ) ;
    printf ( "\n\nRetreiving an element from front of a deque: " ) ;
    item = retrieve_front( ) ;
    if ( item == -1 )
    printf ( "\nDeQueue Empty " ) ;
    else
    printf ( "\n\nFront Item = %d ", item ) ;
    display( ) ;
    printf ( "\n\nRetreiving an element from rear of a deque: " ) ;
    item = retrieve_rear( ) ;
    if ( item == -1 )
    printf ( "\nDeQueue Empty " ) ;
    else
    printf ( "\n\nRear Item = %d ", item ) ;
    display( ) ;
    return 0 ;
}
void add_front ( int x)
{
    int i,j; 
    if ( front == NULL )
    {
        front = a ;
        *( front ) = x ;
        rear = a ;
    }
    else
    {
        front = a ;
        j = rear - front ;
        if ( j != 25 )
        {
            for ( i = j + 1 ; i >= 0 ; i-- )
                front [ i ] = front [ i - 1 ] ;
                *( front + 0 ) = x ;
                rear++ ;
        }
        else
            printf ( "\n DeQueue Full " ) ;
    }
}
//Function to add data at rear
void add_rear ( int item)
{
    int i, j ;
    if ( front == NULL )
    {
        front = a ;
        *front = item ;
        rear = a ;
    }
    else
    {
        i = rear - front ;
        if ( i != 25 )
        {
            rear++ ;
            *rear = item ;
        }
        else
            printf ( "\nDeQueue full " ) ;
    }
}
//Function to retrive data from front
int retrieve_front( )
{
    int item, i, j ;
    if ( front == NULL )
    {
        printf ( "\n DeQueue Empty " ) ;
        return -1 ;
    }
    else
    {
        item = *front ;
        i = rear - front ;
        if ( i == 0 )
        {
            front = NULL ;
            rear = NULL ;
        }
        else
        {
            for ( j = 0 ; j <= i - 1 ; j ++ )
            front [ j ] = front [ j + 1 ] ;
            *rear = 0 ;
            rear-- ;
        }
    }
    return item ;
}
//Function to retrive data at rear
int retrieve_rear( )
{
    int item, i, j ;
    if ( rear == NULL )
    {
        printf ( "\n DeQueue Empty " ) ;
        return -1 ;
    }
    else
    {
        item = *rear ;
        i = rear - front ;
        if ( i == 0 )
        {
            front = NULL ;
            rear = NULL ;
        }
        else
        {
            *rear = 0 ;
            rear-- ;
        }
    } 
    return item ;
}
void display( ) 
{
    int i ;
    int *p = front ;
    if ( p == NULL )
    {
        printf ( "\n\nDeQueue Empty " ) ;
    }
    else
    {
        printf ( "\n" ) ;
        for ( i = 0 ; i <= ( rear - front ) ; i++ )
        printf ( "\n a[ %d ] = %d ", i, *p++ );
    }
}