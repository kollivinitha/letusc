//Swapping the values using pointers
#include<stdio.h>
void swap(int *a,int *b,int *c)
{
    int t=*a;
    *a=*b;
    *b=*c;
    *c=t;
}
int main()
{
    int a,b,c;
    printf("Enter the values of a b c: ");
    scanf("%d %d %d",&a,&b,&c);
    swap(&a,&b,&c);
    printf("Changed Values:\n");
    printf("a=%d\n b=%d\n c=%d\n",a,b,c);
}