//Program to convert an uppercase alphabet to lowercase
#include<stdio.h>
#include<ctype.h>
#define case(a) a+32
int main()
{
    char ch;
    printf("Enter an uppercase Character: ");
    scanf("%c",&ch);
    printf("Lower Case Character is %c",case(ch));
    return 0;
}