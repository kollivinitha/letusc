//Printing the Given Pattern
/*
        1
      2   3
    4   5   6
  7   8   9   10
*/
#include<stdio.h>
#include<math.h>
int main()
{
    int k=0,c=0,x=1;
    int n;
    printf("enter a Number: ");
    scanf("%d",&n);
    int len=(3*n)+1;
    for(int i=0;i<n;i++)
    {
        k=len/2-(2*i);
        c=0;
        for(int j=0;j<len;j++)
        {
            
            if(j==k)
            {
                c+=1;
                printf("%d",x++);
                if(c<i+1 && k+4<len)
                {
                    k+=4;
                }
            }
            else{
                printf(" ");
            }            
        }
        printf("\n");
    }
}