// program to find the range of a set of numbers.
#include<stdio.h>
int main()
{
    int n;
    printf("How many numbers you want to enter: ");
    scanf("%d",&n);
    int min=9999999;
    int max=-1;
    while(n>0)
    {
        int x;
        printf("Enter the number: ");
        scanf("%d",&x);
        //range=maximum value-minimum value
        if(x<min)
            min=x;
        else if(x>max)
            max=x;
        n-=1;
    }
    printf("Range is %d",max-min);
    return 0;
}
