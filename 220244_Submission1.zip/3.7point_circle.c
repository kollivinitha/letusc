// program that will determine whether a point lies inside the circle, on the circle or outside the circle.
#include<stdio.h>
#include<math.h>
int main()
{
    int x,y,r;
    printf("Enter the Centre of the Circle: ");
    scanf("%d %d",&x,&y);
    printf("Enter the Radius: ");
    scanf("%d",&r);
    int x1,y1;
    printf("Enter the Point: ");
    scanf("%d %d",&x1,&y1);
    int d=pow(abs(x-x1),2)+pow((abs(y-y1)),2);
    //int xy=pow(abs(x2-x1),2)+pow(abs(y2-y1),2);
    if(d<r)
        printf("Point lies inside the Circle");
    else if(d==r)
        printf("Point Lies on Circle");
    else
        printf("Point lies outside the Circle");
}