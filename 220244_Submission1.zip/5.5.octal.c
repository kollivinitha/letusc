//Program to find octal equalent of the given number
#include<stdio.h>
int main()
{
    int x;
    printf("Enter a Number: ");
    scanf("%d",&x);
    int res=0;
    while(x!=0)
    {
        res=res*10+(x%8);
        x=x/8;
    }
    int y;
    while(res!=0)
    {
        y=y*10+(res%10);
        res=res/10;
    }
    printf("%d",y);
    return 0;
}