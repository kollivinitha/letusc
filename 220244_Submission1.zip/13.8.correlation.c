// compute the correlation coefficient r
#include<stdio.h>
#include<math.h>
float prod(float *x,float *y,int n)
{
    float s=0;
    for(int i=0;i<n;i++)
    {
        s+=(x[i]*y[i]);
    }
    return s;
}
float sum(float *x,int n)
{
    float s=0;
    for(int i=0;i<n;i++)
    {
        s+=x[i];
    }
    return s;
}
float square(float *x,int n)
{
    float s=0;
    for(int i=0;i<n;i++)
    {
        s+=(pow(x[i],2));
    }
    return s;
}
int main()
{
    int n;
    printf("Enter the number of Elements: ");
    scanf("%d",&n);
    float x[n],y[n];
    for(int i=0;i<n;i++)
    {
        printf("Enter the co-ordinates: ");
        scanf("%f %f",&x[i],&y[i]);
    }
    float xy=prod(&x[0],&y[0],n);
    float x_sum=sum(&x[0],n);
    float y_sum=sum(&y[0],n);
    float x2_sum=square(&x[0],n);
    float y2_sum=square(&y[0],n);
    float r=(xy-(x_sum*y_sum))/sqrt((n*(x2_sum-pow(x_sum,2)))* (n*(x2_sum-pow(x_sum,2))));
    printf("Correlation Coefficient is %f",r);

}