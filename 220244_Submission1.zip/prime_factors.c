/* Find Prime Factors of a number recursively */ 

# include <stdio.h> 
void prime_factors ( int, int ) ; 
int main( ) 
{ 
    int num ; 
    printf ( "Enter a number: " ) ; 
    scanf ( "%d", &num ) ; 
    printf ( "Prime factors are: " ) ; 
    prime_factors ( num, 2 ) ; 
    return 0 ; 
} 
void prime_factors ( int n, int i ) 
{ 
    if ( i > n ) 
    { 
        return;
    }
    if ( n % i == 0 ) 
    { 
        printf ( "%d ", i ) ; 
        n = n / i ; 
    } 
    else 
    i++ ; 
    prime_factors ( n, i ) ; 
}