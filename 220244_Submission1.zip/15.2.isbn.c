/* program that receives a 10-digit integer, computes the checksum, and 
reports whether the ISBN number is correct or not*/
#include<stdio.h>
#include<string.h>
int main()
{
    char num[10];
    printf("Enter the ISBN number: ");
    scanf("%s",&num);
    int s=0,j=1;
    for(int i=9;i>=0;i--)
    {
        int x=num[i]-48;
        s+=(x*j++);
    }
    printf("Checksum is %d\n",s);
    if(s%11 == 0)
        printf("ISBN number is Correct");
    else
        printf("ISBN number is incorrect");
}