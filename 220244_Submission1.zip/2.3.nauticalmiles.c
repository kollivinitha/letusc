//Program to find distance between the latitute and longitude in nautical miles
#include<stdio.h>
#include<math.h>
int main()
{
    double l1,l2,g1,g2;
    printf("Enter the values of latitude(L1,L2): ");
    scanf("%lf %lf",&l1,&l2);
    printf("Enter the values of longitude(G1,G2): ");
    scanf("%lf %lf",&g1,&g2);

    //As per the Formula D = 3963 acos ( sin L1 sin L2 + cos L1cos L2 * cos ( G2 – G1 )
    int d=3963*(acos((sin(l1)*sin (l2))+(cos (l1)*cos (l2)*cos(g2-g1))));
    printf("Distance in Nautical miles is: %d",d);
    return 0;
}