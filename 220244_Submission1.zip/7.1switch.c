//program which to find the grace marks for a student using switch
#include<stdio.h>
int main()
{
    int n,c,grace;
    printf("Enter the number of subjects failed: ");
    scanf("%d",&n);
    printf("Enter the Class obtained: ");
    scanf("%d",&c);
    switch (c)
    {
    case 1:
    {
        if(n>3)
            grace=0;
        else
            grace=5*n;
        break;
    }
    case 2:
    {
        if(n>2)
            grace=0;
        else
            grace=4*n;
        break;
    }
    case (3):
    {
        if(n>1)
            grace=0;
        else 
            grace=5;
        break;
    }
    }
    printf("Grace Obtained is %d",grace);
}