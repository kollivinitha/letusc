#include<stdio.h>
int sum_of_digits(int n,int sum)
{
    //Base Condition to terminate the recursion
    if(n==0)
        return sum;
    //Recursive Call
    sum_of_digits(n/10,sum+(n%10));
}
int main()
{
    int n;
    printf("Enter a number");
    scanf("%d",&n);
    int res=sum_of_digits(n,0);
    printf("sum of Digits is %d",res);
}
