//amount a as per the following formula : a = p ( 1 + r / q ) nq
#include<stdio.h>
#include<math.h>
int main()
{
    int a,p,q,r,n;
    for(int i=0;i<10;i++)
    {
        int num=10;
        while(num!=0)
        {
            printf("Enter the Principal amount: ");
            scanf("%d",&p);
            printf("Enter the compound intrest: ");
            scanf("%d",&q);
            printf("Enter the rate of intrest: ");
            scanf("%d",&r);
            a=p*pow((1+(r/q)),n*q);
            printf("Total Amount is %d\n",a);
            num-=1;
        }
    }

}