//program to check whether the triangle is an isosceles, an equilateral, a scalene or a right-angled triangle.
#include<stdio.h>
#include<math.h>
int main()
{
    int x,y,z;
    printf("Enter the length of the three sides: ");
    scanf("%d %d %d",&x,&y,&z);

    //If all the sides are equal,then it is Equilateral
    if(x==y && x==z)
        printf("The Triangle is Equilateral");

    //If any two sides are equal, then it is Isosceles Triangle
    else if(x==y || x==z || y==z)
        printf("The Triangle is Isosceles Triangle");
    
    //Pythogoras Theorem
    //Sum of two squares of sides is equal to square of third Side,then it is right Angled Triangle
    else if(((x*x)+(y*y)==(z*z))||((y*y)+(z*z)==(x*x))||((x*x)+(z*z)==(y*y)))
        printf("The Triangle is Right Angled Triangle");
     
    //If all sides are different, then it is Scalene Triangleelse
        printf("The Triangle is Scalene");
}