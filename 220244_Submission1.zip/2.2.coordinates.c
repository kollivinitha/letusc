//program to receive Cartesian co-ordinates (x, y) of a point and convert them into polar co-ordinates (r, ).

#include<stdio.h>
#include<math.h>

int main()
{
    int x,y;
    printf("Enter the values of x and y");
    scanf("%d %d",&x,&y);
    
    //As per the Formula
    int r=sqrt((double)pow(x,2)+pow(y,2));
    int pie=atan((double)y/x);
    printf("Polar Co-ordinates (%d ,%d)",r,pie);
}