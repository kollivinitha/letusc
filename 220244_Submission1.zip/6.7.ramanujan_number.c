//program to print all such numbers up to a reasonable limit.
#include<stdio.h>
#include<math.h>
int main()
{
    int limit;
    printf("Enter the limit: ");
    scanf("%d",&limit);
    for(int i=1;i<limit;i++)
    {
        for(int j=1;j<limit;j++)
        {
            for(int k=1;k<limit;k++)
            {
                for(int l=1;l<limit;l++)
                {
                    if(i!=j && i!=k && i!=l && j!=k && j!=l && k!=l)
                    {
                        int x=(k*k*k)+(l*l*l);
                        if((i*i*i)+(j*j*j)==x)
                            printf("Ramanujan Number is %d\n",x);
                    }
                }
            }
        }
    }
}