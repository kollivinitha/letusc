/*
A certain grade of steel is graded according to the following 
conditions:
(i) Hardness must be greater than 50
(ii) Carbon content must be less than 0.7
(iii) Tensile strength must be greater than 5600
The grades are as follows:
Grade is 10 if all three conditions are met
Grade is 9 if conditions (i) and (ii) are met
Grade is 8 if conditions (ii) and (iii) are met
Grade is 7 if conditions (i) and (iii) are met
Grade is 6 if only one condition is met
Grade is 5 if none of the conditions are met
*/
#include<stdio.h>
#include<math.h>
int main()
{
    int h,s;
    float c;
    int grade;
    printf("Enter the value of Hardness: ");
    scanf("%d",&h);
    printf("Enter the value of Carbon content: ");
    scanf("%f",&c);
    printf("Enter the value of Tensile Strength: ");
    scanf("%d",&s);
    int x=h>50;
    int y=c<0.7;
    int z=s>5600;
    grade=(x && y?((x && z)?10:9):((y&&z)?8:0));
    if(x&&z)
        grade=7;
    if(grade==0)
        if(x||y||z)
            grade=6;
        else
            grade=5;
    printf("Grade is %d",grade);
    


}