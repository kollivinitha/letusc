//program to determine the population at the end of each year in the last decade as per the information given
#include<stdio.h>
#include<math.h>
int main()
{
    float p=100000;
    float r=10;
    int incr;
    for(int i=1;i<=10;i++)
    {
        incr=p / pow ( ( 1 + r / 100 ), i );
        printf("The Population after %d year is %d\n",i,incr);
    }
}
