// program to check whether a triangle is valid or not
#include<stdio.h>
#include<math.h>
int main()
{
    int x,y,z;
    printf("Enter the angles of the triangle: ");
    scanf("%d %d %d",&x,&y,&z);
    if(x+y+z == 180)
        printf("Valid Triangle");
    else
        printf("Invalid Triangle");
}