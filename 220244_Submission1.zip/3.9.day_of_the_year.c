//program to find out what is the day on 1st January of the given year.
#include<stdio.h>
#include<math.h>
int is_leap(int Year)
{
    if(Year%400 == 0 && Year%100 != 0 || Year%4 == 0)
    {
        return 1;
    }
    return 0;
}
int main()
{
    int leap=0;
    int year;
    int ref=2001;
    printf("Enter the Year: ");
    scanf("%d",year);
    while(ref<=year)
    {
        if(is_leap(ref))
            leap+=1;
        ref+=1;
    }
    
    //Calculating number of days
    int days=(leap*365)+((year-ref)-leap)*366;
    int d=days%7;
    if(d==0)
        printf("Monday");
    else if(d==1)
        printf("Tuesday");
    else if(d==2)
        printf("Wednesday");
    else if(d==3)
        printf("Thursday");
    else if(d==4)
        printf("Friday");
    else if(d==5)
        printf("Saturday");
    else
        printf("Sunday");
}