//program to generate all Pythagorean Triplets with side length less than or equal to 30
#include<stdio.h>
#include<math.h>
int main()
{
    int a,b,c;
    printf("Pythagorean Triplets\n");
    for(int i=1;i<30;i++)
    {
        for(int j=1;j<30;j++)
        {
            for(int k=1;k<30;k++)
            {
                
                a=i*i;
                b=j*j;
                c=k*k;
                if(a+b==c || b+c==a || c+a==b)
                {
                    printf("%d %d %d\n",i,j,k);
                }
            }
        }
    }
}