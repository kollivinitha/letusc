//program to print 24 hours of day with suitable suffixes like AM, PM, Noon and Midnight.
#include<stdio.h>
#include<math.h>
int main()
{
    int time=0;
    while(time<=24)
    {
        if(time<12)
        {
            printf("Time is %d:00AM\n",time);
        }
        else{
            printf("Time is %d:00PM\n",time);
        }
        time++;
    }
}