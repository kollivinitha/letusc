/* program to find out how many of them are positive, how 
many are negative, how many are even and how many odd. */
#include<stdio.h>
int main()
{
    int n;
    printf("Enter the number of Elements: ");
    scanf("%d",&n);
    int arr[n];
    
    for(int i=0;i<n;i++)
    {
        printf("Enter the Element: ");
        scanf("%d",&arr[i]);
    }
    int sum_p=0,sum_n=0,sum=0;
    for(int i=0;i<n;i++)
    {
        if(arr[i]>0)
            sum_p+=1;
        else if(arr[i]<0)
            sum_n+=1;
        else
            sum+=1;
        if(arr[i]%2 == 0)
            even+=1;
        else
            odd+=1
    }
    printf("Number of Positive Elements:%d\nNumber of Negative Elements:%d\nNumber of Zeroes:%d\nNumber of Even Elements:%d\nNumber of Odd Elements:%d\n",sum_p,sum_n,sum);
}