//Program to obtain the bigger of two numbers.
#include<stdio.h>
#define largest(a,b) a>b?a:b
int main()
{
    int x,y;
    printf("Enter two numbers: ");
    scanf("%d %d",&x,&y);
    printf("Largest Number is %d",largest(x,y));
}