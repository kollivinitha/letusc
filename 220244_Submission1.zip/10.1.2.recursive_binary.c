//Binary Representation of a Number Using RECURSION
#include<stdio.h>
void binary_equivalent(int n)
{
    if(n<0)
        return;
    return binary_equivalent(n/2);
}
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d",&n);
    binary_equivalent(n);
}