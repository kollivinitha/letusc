// program to calculate and print paper sizes
#include<stdio.h>
void print_paper_sizes(int l, int b, int c)
{
    if(c==8)
    {
        return;
    }
    int l1=b;
    int b1=(l/2);
    printf("Paper Size of A%d : %i mm x %i mm\n",c+1,l1,b1);
    print_paper_sizes(l1,b1,c+1);
}
int main()
{
    int l_A0=1189;
    int b_A0=841;
    
    //Creating a function to get paper sizes
    print_paper_sizes(l_A0,b_A0,0);
    return 0;
}
