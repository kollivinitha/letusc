//Formating the data
#include<stdio.h>
#include<string.h>
int main()
{
    char book[][30]={"Discovery of India","My Experiments with Truth","Sunny Days","One More Over"};
    char author[][20]={"Jawaharlal Nehru","Mahatma Gandhi","Sunil Gavaskar","Erapalli Prasanna"};
    float price[]={425.50,375.50,95.50,85};
    for(int i=0;i<4;i++)
    {
        printf("%-25s\t%-16s\t%-6.2f\n",book[i],author[i],price[i]);
    }
    return 0;
}