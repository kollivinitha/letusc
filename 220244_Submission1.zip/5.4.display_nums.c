//Program to calculate number of positive,negative,zeroes numbers entered
#include<stdio.h>
int main()
{
    int n;
    printf("How many numbers you want to Enter: ");
    scanf("%d",&n);
    int i=1,pos=0,neg=0,zero=0;
    while(i<=n)
    {
        int x;
        printf("Enter the %dst number: ",i);
        scanf("%d",&x);
        printf("%d",x);
        if(x>0)
        {
            pos+=1;
        }
        else if(x<0)
        {
            neg+=1;
        }
        else
        {
            zero+=1;
        }i+=1;
    }
    printf("Number of Positive Numbers : %d\n Number of Negative Integers: %d\n Number of Zeroes: %d",pos,neg,zero);
}