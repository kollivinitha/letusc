??Program to calculate Body Mass Index based on the information given
#include<stdio.h>
#include<math.h>
int main()
{
    int h,w;
    printf("Enter the Height of a person: ");
    scanf("%d",&h);
    printf("Enter the Weight of a person: ");
    scanf("%d",&w);
    float bmi=w/(pow(h,2));
    if(bmi<15)
        printf("Starvation");
    else if(bmi>=15.1 && bmi<=17.5)
        printf("Anorexic");
    else if(bmi>=17.6 && bmi<=18.5)
        printf("Underweight");
    else if(bmi>=18.6 && bmi<=24.9)
        printf("Ideal");
    else if(bmi>=25 && bmi<=25.9)
        printf("Overweight");
    else if(bmi>=30 && bmi<=30.9)
        printf("Obese");
    else
        printf("Morbidly Obese");
}