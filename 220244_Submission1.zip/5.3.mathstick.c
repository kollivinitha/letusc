//program for a matchstick game being played between the computer and a user. Your program should ensure that the computer always wins
#include<stdio.h>
int main()
{
    int x;
    int total=0;
    while(1)
    {
        printf("No of Matches left :%d\n",21-total);
        printf("Choose 1,2,3 or 4 matches: ");
        scanf("%d",&x);
        
        printf("Computer Chosen %d\n",5-x);
        total+=5;
        if(total==20)
        {
            printf("You Lost!!!");
            break;
        }
    }
    return 0;
}