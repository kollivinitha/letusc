/*program to check if 
arr[ 0 ] = arr[ n - 1 ], arr[ 1 ] = arr[ n - 2 ] and so on*/
#include<stdio.h>
int main()
{
    int n;
    printf("Enter the number of Elements: ");
    scanf("%d",&n);
    int arr[n];
    
    for(int i=0;i<n;i++)
    {
        printf("Enter the Element: ");
        scanf("%d",&arr[i]);
    }
    for(int i=0;i<n/2;i++)
    {
        if(arr[i]==arr[n-i-1])
        {
            printf("arr[%d] is not same as arr[%d] is %d\n",i,(n-i-1),arr[i]);
        }
        else
        {
            printf("arr[%d] is same as arr[%d]\n",i,(n-i-1));
        }
    }
}