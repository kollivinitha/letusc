//a program to find whether the area of the rectangle is greater than its perimeter.
#include<stdio.h>
int main()
{
    int l,b;
    printf("Enter the length and Breadth: ");
    scanf("%d %d",&l,&b);
    int area=l*b;
    int perimeter=0.5*(l+b);
    if(area>perimeter)
        printf("YES");
    else
        printf("NO");
}