#include<stdio.h>
int main()
{
    char source[20]="Hello!";
    char target[]="folks";
    strcat(
        source,target
    );
    
    printf("String is %s",source);
}