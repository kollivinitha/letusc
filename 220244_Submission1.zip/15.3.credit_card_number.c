//Program to check for A valid Credit Card number
#include<stdio.h>
#include<string.h>
int main()
{
    char num[16];
    printf("Enter the Credit card Number: ");
    scanf("%s",&num);
    int s=0,s1=0;
    for(int i=15;i>=0;i--)
    {
        if(i%2==0)
        {
            int x=(num[i]-48)*2;
            if(x>9)
                x-=9;
            s+=x;
        }
        else{
            s1+=num[i]-48;
        }
    }
    s+=s1;
    if(s%10 == 0)
        printf("Valid Credit Card Number");
    else
        printf("Not a Valid Credit card Number");

}