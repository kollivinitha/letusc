// program to calculate the area and perimeter of the rectangle, and the area and circumference of the circle.
#include<stdio.h>
#include<math.h>
void main()
{
    int l,b,r;
    printf("Enter the length of rectangle: ");
    scanf("%d",&l);
    printf("Enter the breadth of rectangle: ");
    scanf("%d",&b);
    printf("Enter the radius of circle: ");
    scanf("%d",&r);

    //Area of rectangle is length x breadth
    printf("Area of Rectangle is %d\n",l*b);

    //Perimeter of Rectangle is 2(length + breadth)
    printf("Perimeter of Rectangle is %d\n",2*(l+b));

    //Area of Circle is 3.14(pie)xrxr
    int area=(int)(pow(r,2));
    printf("Area of circle is %d",area);

    //Circumference of Circle is 2x3.14(pie)xr
    printf("Circumference of Circle is %.2f",(6.28*r));

}