// Printing The Fibanocci Series upto a given Number

#include<stdio.h>
int fib(int n);
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d",&n);
    printf("Fibanocci Series: ");
    for(int i=1;i<n;i++)
    {
        printf("%d ",fib(i));
    }
}
int fib(int c)
{
    if(c<2)
        return c;
    else
        return fib(c-1)+fib(c-2);
}