// program that converts RGB color to CMYK color as per the following formulae
 /*
      Cyan = (White-Red/255)/White
      Magenta =(White-Green/255)/White
      Yellow = (White-Blue/255)/White
      Black = 1−White
    */
#include<stdio.h>
#include<math.h>
int main()
{
    int r,g,b;
    printf("Enter the values of (RGB): ");
    scanf("%d %d %d",&r,&g,&b);
    int w,c,m,y,k;
    int r1=r/255;
    int g1=g/255;
    int b1=b/255;

    //White = Max(Red / 255,Green/ 255,Blue / 255)
    if(r1>g1 && r1>b1)
        w=r1;
    else if(g1>r1 && g1>b1)
        w=g1;
    else
        w=b1;

    c=(w-r1)/w;
    m=(w-g1)/w;
    y=(w-b1)/w;
    k=1-w;
    printf("(%d%d%d%d)",c,m,y,k);
    return 0;
}