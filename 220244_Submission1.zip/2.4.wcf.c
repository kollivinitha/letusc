//Program to calculate wind chill factor 
#include<stdio.h>
#include<math.h>
int main()
{
    int t,v;
    printf("Enter the temperature and wind velocity: ");
    scanf("%d %d",&t,&v);

    //Formula is wcf = 35.74 + 0.6215t + ( 0.4275t - 35.75 ) * v0.1
    int wcf=35.74+(0.6215*t)+((0.4275*t)-35.75)*pow(v,0.16);
    printf("Wind-Chill factor: %d",wcf);

}