//program to print the multiplication table of the number entered by the user
#include<stdio.h>
#include<math.h>
int main()
{
    int x;
    printf("Enter the Number:");
    scanf("%d",&x);
    for(int i=1;i<=10;i++)
        printf("%d * %d = %d\n",x,i,x*i);
}