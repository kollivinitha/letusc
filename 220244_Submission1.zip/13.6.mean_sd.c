//Program to compute the standard deviation and the mean
#include<stdio.h>
#include<math.h>
int find_mean(int *arr,int n)
{
    int s=0;
    for(int i=0;i<n;i++)
    {
        s+=arr[i];
    }
    return (s/n);
}
float find_sd(int *arr,int n,int x)
{
    float s=0;
    for(int i=0;i<n;i++)
    {
        s+=pow(arr[i]-x,2);
    }
    float f=sqrt(s);
    return f/n;
}
int main()
{
    int n;
    printf("Enter the number of Elements: ");
    scanf("%d",&n);
    int arr[n];
    
    for(int i=0;i<n;i++)
    {
        printf("Enter the Element: ");
        scanf("%d",&arr[i]);
    }
    int x=find_mean(&arr[0],n);
    printf("Mean of the Observations: %d\n",x);
    float y=find_sd(&arr[0],n,x);
    printf("Standard Deviation is %f",y);
}