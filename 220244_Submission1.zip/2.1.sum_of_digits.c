//Program to calcute sum of digits in five-digit number
#include<stdio.h>
int main()
{
    int num;
    printf("Enter the five digit number: ");
    scanf("%d",&num);
    int sum=0;
    while (num!=0)
    {
        // modulo(%) operator gives remainder
        sum+=num%10;
        num=num/10;
    }
    printf("Sum of digits is: %d",sum);
}