// program to check if the three points fall on one straight line.
#include<stdio.h>
#include<math.h>
int main()
{
    int x1,x2,x3,y1,y2,y3;
    printf("Enter first Point: ");
    scanf("%d %d",&x1,&y1);
    printf("Enter Second Point: ");
    scanf("%d %d",&x2,&y2);
    printf("Enter Third Point: ");
    scanf("%d %d",&x3,&y3);
    int xy = abs ( x2- x1 ) / abs ( y2 - y1 ) ; 
    int xz = abs ( x3 - x1 ) / abs ( y3 - y1 ) ; 
    int yz = abs ( x3 - x2 ) / abs ( y3 - y2 ) ;
    if((xy == xz) && (xy==yz))
    
        printf("Three Points lies on straight line");
    else
        printf("Three Points doesnot lie on straight line");
}